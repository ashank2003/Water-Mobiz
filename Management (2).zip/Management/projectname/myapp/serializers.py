from rest_framework import serializers
from .models import Branch, BranchDetails,Dropdown,Product

class BranchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = '__all__'

class BranchDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = BranchDetails
        fields = '__all__'

class DropdownSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dropdown
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'