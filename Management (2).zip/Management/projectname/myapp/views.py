from rest_framework import viewsets
from .models import Branch, BranchDetails,Dropdown,Product
from .serializers import BranchSerializer, BranchDetailsSerializer,DropdownSerializer,ProductSerializer
from rest_framework import generics

class BranchViewSet(viewsets.ModelViewSet):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer

class BranchUpdateView(generics.UpdateAPIView):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer

class BranchDeleteView(generics.DestroyAPIView):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer



class BranchDetailsViewSet(viewsets.ModelViewSet):
    queryset = BranchDetails.objects.all()
    serializer_class = BranchDetailsSerializer


class DropdownViewSet(viewsets.ModelViewSet):
    queryset = Dropdown.objects.all()
    serializer_class = DropdownSerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer