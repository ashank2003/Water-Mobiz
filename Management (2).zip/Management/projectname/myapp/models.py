from django.db import models

class Branch(models.Model):
    si = models.AutoField(primary_key=True)
    branch_name = models.CharField(max_length=255)
    user_name = models.CharField(max_length=255)
    password = models.CharField(max_length=255, editable=True, null=True, blank=True)

    def __str__(self):
        return self.branch_name



class BranchDetails(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    landline = models.CharField(max_length=20)
    email_id = models.EmailField()
    mob_no = models.CharField(max_length=15)
    fax_no = models.CharField(max_length=15)
    website = models.URLField()
    logo = models.ImageField(upload_to='branch_logos/',null=True)

    def __str__(self):
        return f"{self.branch.branch_name} Details"



class Dropdown(models.Model):
    Type = (
        ('A', 'Abu Dhabi'),
        ('D', 'Dubai'),
        ('Aj', 'Ajman'),
        ('U', 'Umm Alquain'),
        ('S', 'Sujeirh'),
        ('R', 'Ras Al Khaimah'),
        ('Sh', 'Sharjah'),
    )
    country = (
        ('U', 'UAE'),
    )
    Emirate_Name = models.CharField(max_length=100, choices=Type)
    Lattitude_Value = models.CharField(max_length=100)
    Longitude_Value = models.CharField(max_length=100)
    Country=models.CharField(max_length=20,choices=country)



class Product(models.Model):
    Product_Name = models.CharField(max_length=255)
    Product_Id_or_Barcode = models.CharField(max_length=255)
    Select_Unit = models.CharField(max_length=50)
    Default_Rate = models.DecimalField(max_digits=10, decimal_places=2)
    Main_Unit = models.CharField(max_length=50)
    Base_Unit = models.CharField(max_length=50)
    Standard_Packet_Size = models.PositiveIntegerField()
    Coupon = models.BooleanField(default=False)

    def __str__(self):
        return self.Product_Name