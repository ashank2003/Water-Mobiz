from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BranchViewSet,BranchUpdateView,BranchDeleteView, BranchDetailsViewSet,DropdownViewSet,ProductViewSet

router = DefaultRouter()
router.register(r'Branches', BranchViewSet)
router.register(r'Emirite', BranchDetailsViewSet)
router.register(r'City', DropdownViewSet)
router.register(r'Products', ProductViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('Branches/<int:pk>/update/',BranchUpdateView.as_view(), name='product-update'),
    path('Branches/<int:pk>/delete/', BranchDeleteView.as_view(), name='product-delete'),
]

